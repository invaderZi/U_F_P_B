
import java.util.Scanner;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import static java.lang.String.format;

/*#######################
Universidade federal da paraiba
Aluno : Sabrina Alicrim Silva
Matricula: 2016022764
########################

- Projeto 1 S.O - Escalonador de processos
______________________________________________________________________________

- Instruções para compilação e execução: 
abrir terminal do ubuntu na pasta do arquivo e executar os comandos:

	$ javac EscalonadorDeProcessos.java
	$ java EscalonadorDeProcessos

(para execução na ide netbeans, é necessario criar um projeto e adicionar o arquivo)
_______________________________________________________________________________

Instrucoes para entrada: 
casa linha corresponde a um processo os parametros sao separados por espaço, pode utilizar o "enter" para pular para a proxima linha.
um "enter" numa linha vazia indica o fim da entrada

exemplo de entrada :
0 20
0 10
4 6
4 8


*/

//__________________________________________________________________________________

public class EscalonadorDeProcessos {

	public static List<Processo> listaProcessos = new ArrayList<Processo>(); //Cria uma lista com generalizada com processos do tipo Processo (classe)
	public static Scanner input = new Scanner(System.in);; // cria um obj do tipo scanner para leitura dos dados

	public static void main(String[] args) {
		/**Metodo main da classe principal**/
		
		int id = 0; //id genérico para a lista de processos
		while (true) { 
			String dados_in[] = input.nextLine().split(" ");   // seta os parametros da entrada pulando o "espaco"
			if (dados_in[0].isEmpty() || dados_in[1].isEmpty()) {  // caso alguma  das informacoes da linha esteja vazia, indica o fim da entrada
				input.close();  //finaliza a entrada
				break; 
			}
			listaProcessos.add(new Processo(++id, Integer.parseInt(dados_in[0]), Integer.parseInt(dados_in[1]))); // adiciona processos a lista geral
		}
		
        FCFS fcfs = new FCFS(listaProcessos);  //chamada do construtor do escalonador FCFS, passando a lista do imput como parametro
        SJF sjf = new SJF(listaProcessos);	   //chamada do construtor do escalonador SJS, passando a lista do imput como parametro
        RR rr = new RR(listaProcessos);		   //chamada do construtor do escalonador RR, passando a lista do imput como parametro
        
        //impressao dos resultados

        fcfs.imprimirResultados();
        sjf.imprimirResultados();
        rr.imprimirResultados();

			/**fim do  main **/

	}

	// fim da classe principal

}
class Processo implements Comparable<Processo> {  
//implementa comparable para utilização dos metodos de ordenação compareTo e sort da biblioteca collections

	/* variaveis comuns a todos os processos */

	public int numerodoprocesso;
	public int tempoChegada;
	public int duracao;
	public int duracaoRestante;


	public Processo(int numerodoprocesso, int tempoChegada, int duracao) {
		//construtor da classe
		this.numerodoprocesso = numerodoprocesso;
		this.tempoChegada = tempoChegada;
		this.duracao = duracao;
		this.duracaoRestante = duracao;
	}


	
	//metodo para ordenar a lista de processos de acordo com a duracao e tempo de chegada 
	
	public int compareTo(Processo p) {
		if ( (this.tempoChegada < p.tempoChegada || this.tempoChegada == p.tempoChegada)
				&& (this.duracao < p.duracao )) {
			return -1;
		} else if ( (this.tempoChegada > p.tempoChegada )|| (this.tempoChegada == p.tempoChegada && this.duracao > p.duracao )){
			return 1;
		} else {
			return 0;
		}
	}



}

class Escalonador {

	/* variaveis comuns a todos os escalonadores*/

    public float retornoMedio;
    public float respostaMedio;
    public float esperaMedio;
 
   
    
    public int menorTempoDeChegada(List<Processo> processos) {


    // metodo que retorna o tempo de chegada menor dentre todos os processos

    	int menor = Integer.MAX_VALUE;

    	for (Processo p : processos) {
			if(p.tempoChegada < menor)
				menor = p.tempoChegada;
		}
    	return menor;
    }
    
    
    public int getTotalProcessos(List<Processo> processos) {

     
     // Obtem o total de processos na lista ffazendo um size() da lista de processos
    
        return processos.size();
    }

    public void imprimirResultados(String tipoEscalonador) {

   	 /*
     * Imprime os resultados do escalonador: - Tempo de retono médio - Tempo de
     * resposta médio - Tempo de espera médio, de acordo com as especificacoes do projeto :
			exemplo : 
					FCFS 30,5 19,5 19,5
					SJF 21,5 10,5 10,5
					RR 31,5 2,0 20,5

     */

        System.out.println(format("%s %.1f %.1f %.1f", tipoEscalonador, retornoMedio, respostaMedio, esperaMedio));
    }
}



/*
	 * Implementação do FCFS
	 */

class FCFS extends Escalonador { //Classe FSFS extende a classe escalonador

	public static List<Processo> listaProcessosProntos;

	

	public FCFS(List<Processo> processos) {
		// construtor da classe FCFS
		
		try {

			listaProcessosProntos = new ArrayList<Processo>(processos); //cria uma lista para adicionar os processos prontoss

			int tempoRetorno = 0, tempoResposta = 0, tempoEspera = 0; 	//seta as variaveis inicialmente para 0

			int totalProcessos = processos.size();   // total de processos = tamanho da lista de processos 

			int retorno = menorTempoDeChegada(processos);	// tempo de retorno incial = menor tempo de chegada
			
			// enquanto existir processos na fila de prontos
			while (!listaProcessosProntos.isEmpty()) {
				Processo p = listaProcessosProntos.remove(0); // obtem o primeiro processo da fila e remove da lista
				retorno += p.duracao;						  // retorno = retorno+duracao
				tempoRetorno += (retorno - p.tempoChegada);	  // tempo de retorno = retorno - tempo de chegada 
				tempoEspera += (retorno - p.tempoChegada - p.duracao); // TEspera= (Retorno - Chegada - duracao)
			}
			
			tempoResposta = tempoEspera; // Para o FCFS o tempo de resposta é igual ao tempo de espera

			// calculo dos tempos médios
			super.retornoMedio =  (float) tempoRetorno/totalProcessos;
			super.respostaMedio =  ( float )tempoResposta/totalProcessos;
			super.esperaMedio =  (float) tempoEspera /totalProcessos;
                        
                        
                        
		} catch (Exception e) {

			System.err.println(e.getMessage());
		}
	}
	

	/**
	 * Imprime os resultados
	 */
	public void imprimirResultados() {
		super.imprimirResultados("FCFS");
	}

 // fim FCFS
}



/* Implementação do SJF
	 */

class SJF extends Escalonador { // sjf extende a classe escalonador 
	//ESCALONADOR SEM PREEMPCAO

    private static List<Processo> listaProcessosProntos = new ArrayList<Processo>();  //lista de processos prontos

    public SJF(List<Processo> processos) {
    	// inicio construtor da classe

        try {
            int tempoRetorno = 0, tempoResposta = 0, tempoEspera = 0; 	// seta parametros pra zero
            int totalProcessos = super.getTotalProcessos(processos);	// salva numero de processos existentes
            int retorno = menorTempoDeChegada(processos);				
            preparalistaProcessosProntos(processos);					// chamada do metodo da classe sjf

            // enquanto houver processos
			while (!listaProcessosProntos.isEmpty()) { // enquanto lista nao tiver vazia
				Processo p = listaProcessosProntos.remove(0); // obtem o primeiro processo da fila e remove da fila
				retorno += p.duracao;
				tempoRetorno += (retorno - p.tempoChegada);				
				tempoEspera += (retorno - p.tempoChegada - p.duracao); // Tespera = (Retorno - Chegada - duracao)
			}

			tempoResposta = tempoEspera; // Para o SJF o tempo de resposta é igual ao tempo de espera

            // calcula os tempos médios

            retornoMedio = (float) tempoRetorno / totalProcessos;
            respostaMedio= (float) tempoResposta / totalProcessos;
            esperaMedio =  (float) tempoEspera / totalProcessos;
        
        } catch (Exception e) {

            System.err.println(e.getMessage());
        }
    }
    
    /**
     * Ordena a lista de acordo com o tempo de chegada e duração do processo e prepara uma lista de prontos
     */
	private void preparalistaProcessosProntos(List<Processo> processos) {

		List<Processo> p = new ArrayList<Processo>(processos);

		int sumRetorno = 0, menor = 0, aux = 0;
		// Ordena a lista para garantir a hierarquia de chegada
		Collections.sort(p); // usando funcao de sort


		listaProcessosProntos.add(p.remove(0)); //adiciona a lista
		sumRetorno = listaProcessosProntos.get(0).duracao;

		while(p.size() > 1) { //enquanto a lista tiver mais que 1 elemento
			aux = 0;
			for(int i = 1; i < p.size(); i++) { //percorre a lista
				if(p.get(aux).duracao<= p.get(i).duracao&& p.get(aux).tempoChegada< sumRetorno) //se duracao (0) <= duracao (1) && tempochegada(0) < somatemporetorno
					menor = aux; //menor = 0
				else if(p.get(i).tempoChegada < sumRetorno) { //se tempodechegada(1) < somaretorno
					aux = i;           //aux = i = menor =  1
					menor = i;
				}
			}
			sumRetorno += p.get(menor).duracao;  //soma duracao ao tempo de retorno
			listaProcessosProntos.add(p.remove(menor)); //adiciona a lista de prontos
		}	

		// add o ultimo processo a lista, na ultima posicao
		if(p.size() == 1)
			listaProcessosProntos.add(p.remove(0));
}

    /**
     * Imprime as métricas
     */
    public void imprimirResultados() {
        super.imprimirResultados("SJF");
    }

    // fim do SJF
}



class RR extends Escalonador { // classe RR extende escalonador 

    public static final int QUANTUM = 2; // tempo maximo de permanencia do processo na cpu 

    public static List<Processo> listaProcessosProntos = new ArrayList<Processo>();
    public static List<Integer> listaTemposDeChegada = new ArrayList<Integer>();
    public static Map<Integer, Integer> temposResposta = new HashMap<Integer, Integer>(); 

    public RR(List<Processo> processos) {
    	
    	//construtor da classe rr INICIO

        int tempoRetorno = 0, tempoEspera = 0;

        int totalProcessos = super.getTotalProcessos(processos);
        int retorno = menorTempoDeChegada(processos);
        preparalistaProcessosProntos(processos, retorno);

        // enquanto houver processos na lista de prontos
        while (!listaProcessosProntos.isEmpty()) {
	            Processo p = listaProcessosProntos.remove(0);
	            
            	/**
            	 * Para obter o tempo de resposta (intervalo entre a chegada ao sistema e inicio de sua execução)
            	 * é utilizado um Map (temposReposta), o key é o processo e o value é o tempo em que o processo foi atendido
            	 * Se o processo já foi atendido ele é ignorado e o tempo de resposta não é computado. 
            	 */
                if(!temposResposta.containsKey(p.numerodoprocesso))
                	temposResposta.put(p.numerodoprocesso, retorno - p.tempoChegada);
                
	            /**
	             * Verifica se o processo da vez possui tempo restante maior que o QUANTUM
	             * Caso contrário o resto do tempo é pego e o processo finalizado
	             */
	            if (p.duracaoRestante > QUANTUM) {
	                p.duracaoRestante = (p.duracaoRestante - QUANTUM);
	                retorno += QUANTUM;
	                preparalistaProcessosProntos(processos, retorno);
	               
	                // adiciona o processo no final da lista, pois não foi finalizado
	                listaProcessosProntos.add(p);
	            } else {
	                retorno += p.duracaoRestante;
	            }

		        /**
		         * Verifica se o processo foi finalizado. 
		         * Se finalizado, é calculado as métricas deste processo
		         */
		        if (!listaProcessosProntos.contains(p)) {
		            tempoRetorno += retorno - p.tempoChegada;
		            tempoEspera += (retorno - p.tempoChegada - p.duracao); // TE = (RETORNO - CHEGADA - TAMANHO)
		        }
        }

        /**
         * Depois que todos os processos foram executados a média das métricas é calculada
         */
        super.retornoMedio = (float) tempoRetorno / totalProcessos;
        super.respostaMedio = (float) somaTemposDeResposta() / totalProcessos;
        super.esperaMedio  = (float) tempoEspera / totalProcessos;

        //construtor da classe FIM
    }
    
    /*
     * Prepara a lista de prontos de acordo com o tempo de chegada
     */

    private void preparalistaProcessosProntos(List<Processo> processos, int retorno) {
    	
    	int menor = 0;

    	for (Processo p : processos) {
			if(!listaTemposDeChegada.contains(p.tempoChegada) && p.tempoChegada <= retorno) {
				if(!listaProcessosProntos.contains(p)) { // se o processo nao estiver na lista de prontos
					menor = p.tempoChegada; //menor processo é o que chegou
        			listaTemposDeChegada.add(menor); //adiciona processo a lista de prontos
					for (Processo processo : processos) {
						if(processo.tempoChegada == menor) // se o processo tem o menor tempo de chegada
							listaProcessosProntos.add(processo); // é adicionado na lista de prontos
					}
				}
			}
		}
    }
    

    /**
     * Retorna o somatório do tempo de resposta de tdos os processos
     * @return
     */
      private int somaTemposDeResposta() {
    	int sumResposta = 0;
        sumResposta = temposResposta.keySet().stream().map((key) -> temposResposta.get(key)).reduce(sumResposta, Integer::sum);
    	return sumResposta;
    }
    
    /**
     * Imprime os resultados
     */
    public void imprimirResultados() {
        super.imprimirResultados("RR");
    }

// fim RR
}


