/*#######################
Universidade federal da paraiba
Aluno : Sabrina Alicrim Silva
Matricula: 2016022764
########################

----------------------------------- Projeto 2 S.O - Algoritimos de troca de pagina
______________________________________________________________________________

- Instruções para compilação e execução: 
abrir terminal do ubuntu na pasta do arquivo e executar os comandos:

	$ javac Faltadepagina.java
	$ java Faltadepagina

_______________________________________________________________________________

Instrucoes para entrada: 
 MODIGICAR ARQUIVO entrada.txt LOCALIZADO NA MESMA PASTA QUE ESTE CODIGO

A entrada é composta por uma série números
inteiros, um por linha, indicando, primeiro a
quantidade de quadros disponíveis na memória
RAM e, em seguida, a sequência de referências à
memória.


exemplo de entrada :
4
1
2
3
4
1
2
5
1
2
3
4
5


SALVAR NO entrada.txt


*/

//__________________________________________________________________________________


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;




public class Faltadepagina {

  private static ArrayList<Integer> sequenciaRefPag = new ArrayList<>();
  
   public static void main(String[] args) {

       //PERSISTENCIA DE ARQUIVO//
     try {
       String arquivo = "entrada.txt"; //nome do arquivo de entrada
       String line = "";

       BufferedReader readFile =
	                  new BufferedReader(new FileReader(arquivo));

       int numerodequadros = Integer.parseInt(readFile.readLine());

       while ((line = readFile.readLine()) != null) {
         sequenciaRefPag.add(Integer.parseInt(line));
       }
       
       //CHAMADA DOS METODOS

      FIFO(numerodequadros);
      OTM(numerodequadros);
      LRU(numerodequadros);

     }
     catch (IOException | NumberFormatException e) {
     }

  }

  public static void FIFO(int numerodequadros) {
    int faltadepag = 0; //inicia com 0 faltas de paginas
    int i = 0;
    ArrayList<Integer> quadros = new ArrayList<Integer>(); //Lista de quadros disponiveis na memoria
    for (int j = 0; j < numerodequadros; j++) {quadros.add(-1);} //zerando lista (inicia em -1 pq o primeiro indice da pagina e zero)

    for (Integer referencia : sequenciaRefPag) { //ate o  final da lista de referencias de paginas
      if (!quadros.contains(referencia)) { // Falta de pagina!!
        quadros.set(i, referencia);        // Adiciona o elemento no indice correto
        i = (i+1) % quadros.size(); // Atualiza Circular
        faltadepag++;              // Atualiza contador de falta de paginas
      }
    }

    System.out.println("FIFO " + faltadepag);
  }

  public static void OTM(int numerodequadros) {
    int faltadepag = 0;
    int i = 0;
    int primeiraRef = numerodequadros;
    int distancia[] = new int[numerodequadros];
    int vitima = 0;
    int indice = 0;
    ArrayList<Integer> quadros = new ArrayList<Integer>(); //de lista quadros disponiveis na memoria
    for (int j = 0; j < numerodequadros; j++) {quadros.add(-1);} //zerando

    for (Integer p : sequenciaRefPag) {
      if (!quadros.contains(p)) { // deu Falta de pagina  p nao existe  na lista de quados na memoria 
        faltadepag++;

        if (primeiraRef != 0) {   // Primeira referencia
          quadros.set(i, p);
          primeiraRef--; 
        }
        else { // Verifica qual quadro "vitima" 
          vitima = 0;
          distancia = new int[numerodequadros];
          for (Integer q : quadros) {
            for (int k = i; k < sequenciaRefPag.size(); k++) {
              if (sequenciaRefPag.get(k) == q){
                break;
              }
              distancia[vitima]++;
            }
            vitima++;
          }
          // Verifica maior distancia 
          vitima = -1;
          indice = 0;
          for (int k = 0; k < numerodequadros; k++) {
            if (distancia[k] > vitima){
              vitima = distancia[k];
              indice = k;
            }
          }
          quadros.set(indice, p);
        }
      }
      i++;
    }
    System.out.println("OTM " + faltadepag);
  }

  public static void LRU(int numdequados){
    int faltadepagina = 0;
    int i = 0;
    int primeiraref = numdequados;
    int contadordereferencia[] = new int[numdequados];
    int contadortempo = 0;
    ArrayList<Integer> quadros = new ArrayList<Integer>();
    for (int j = 0; j < numdequados; j++) {quadros.add(-1);}

    for (Integer p : sequenciaRefPag) {

      if (!quadros.contains(p)) { //  Falta de pagina
        faltadepagina++;
        if (i < numdequados) {
          quadros.set(i, p);
          contadordereferencia[i] = i;
        }
        else {
          //Busca o menor indice do contador
          int menor = Integer.MAX_VALUE;
          int indice = 0;
          for (int k = 0; k < numdequados; k++) {
            if (contadordereferencia[k] < menor) {
              menor = contadordereferencia[k];
              indice = k;
            }
          }
          contadordereferencia[indice] = i;
          quadros.set(indice, p);
        }
      }
      else { //nao ocorreu falta de pagina
        //busca indice da referencia e atualiza contador de ref
        for (int k = 0; k < numdequados; k++) {
          if (quadros.get(k) == p){
            contadordereferencia[k] = i;
            break;
          }
        }
      }
      i++;
    }
    System.out.println("LRU " + faltadepagina);
  }

 
}